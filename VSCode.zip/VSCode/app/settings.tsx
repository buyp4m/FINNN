import React from 'react';
import { 
  StyleSheet, 
  Text, 
  View, 
  ScrollView, 
  TouchableOpacity,
  Switch 
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Stack } from 'expo-router';
import { 
  Bell, 
  Shield, 
  Globe, 
  Download, 
  Trash2,
  ChevronRight,
  Moon,
  Smartphone,
  DollarSign
} from 'lucide-react-native';
import { Colors } from '@/constants/colors';

export default function SettingsScreen() {
  const [notifications, setNotifications] = React.useState(true);
  const [darkMode, setDarkMode] = React.useState(false);
  const [biometric, setBiometric] = React.useState(true);

  const settingsGroups = [
    {
      title: 'Preferencias',
      items: [
        { 
          icon: Bell, 
          title: 'Notificaciones', 
          subtitle: 'Alertas y recordatorios',
          type: 'switch',
          value: notifications,
          onToggle: setNotifications
        },
        { 
          icon: Moon, 
          title: 'Modo Oscuro', 
          subtitle: 'Cambiar apariencia de la app',
          type: 'switch',
          value: darkMode,
          onToggle: setDarkMode
        },
        { 
          icon: Globe, 
          title: 'Idioma', 
          subtitle: 'Español',
          type: 'navigation'
        },
        { 
          icon: DollarSign, 
          title: 'Moneda', 
          subtitle: 'USD - Dólar Americano',
          type: 'navigation'
        },
      ]
    },
    {
      title: 'Seguridad',
      items: [
        { 
          icon: Shield, 
          title: 'Autenticación Biométrica', 
          subtitle: 'Usar huella o Face ID',
          type: 'switch',
          value: biometric,
          onToggle: setBiometric
        },
        { 
          icon: Smartphone, 
          title: 'Código de Acceso', 
          subtitle: 'Configurar PIN de 4 dígitos',
          type: 'navigation'
        },
      ]
    },
    {
      title: 'Datos',
      items: [
        { 
          icon: Download, 
          title: 'Exportar Datos', 
          subtitle: 'Descargar información financiera',
          type: 'navigation'
        },
        { 
          icon: Trash2, 
          title: 'Eliminar Datos', 
          subtitle: 'Borrar toda la información',
          type: 'navigation',
          danger: true
        },
      ]
    }
  ];

  const renderSettingItem = (item: any, index: number) => {
    const IconComponent = item.icon;
    
    return (
      <TouchableOpacity 
        key={index} 
        style={[styles.settingItem, item.danger && styles.dangerItem]}
      >
        <View style={styles.settingLeft}>
          <View style={[
            styles.settingIcon,
            { backgroundColor: item.danger ? `${Colors.expense}15` : `${Colors.primary}15` }
          ]}>
            <IconComponent 
              color={item.danger ? Colors.expense : Colors.primary} 
              size={20} 
            />
          </View>
          <View style={styles.settingContent}>
            <Text style={[
              styles.settingTitle,
              item.danger && { color: Colors.expense }
            ]}>
              {item.title}
            </Text>
            <Text style={styles.settingSubtitle}>{item.subtitle}</Text>
          </View>
        </View>
        
        {item.type === 'switch' ? (
          <Switch
            value={item.value}
            onValueChange={item.onToggle}
            trackColor={{ false: Colors.lightGray, true: Colors.primary }}
            thumbColor={item.value ? Colors.white : Colors.gray}
          />
        ) : (
          <ChevronRight color={Colors.gray} size={20} />
        )}
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <Stack.Screen 
        options={{ 
          title: 'Configuración',
          headerStyle: { backgroundColor: Colors.light },
          headerTintColor: Colors.dark,
        }} 
      />
      
      <ScrollView showsVerticalScrollIndicator={false}>
        {settingsGroups.map((group, groupIndex) => (
          <View key={groupIndex} style={styles.settingsGroup}>
            <Text style={styles.groupTitle}>{group.title}</Text>
            <View style={styles.groupItems}>
              {group.items.map((item, itemIndex) => renderSettingItem(item, itemIndex))}
            </View>
          </View>
        ))}

        {/* App Info */}
        <View style={styles.appInfo}>
          <Text style={styles.appName}>FinanceAI</Text>
          <Text style={styles.appVersion}>Versión 1.0.0</Text>
          <Text style={styles.appDescription}>
            Tu asistente financiero inteligente para gestionar tus finanzas personales
          </Text>
        </View>

        {/* Legal Links */}
        <View style={styles.legalSection}>
          <TouchableOpacity style={styles.legalItem}>
            <Text style={styles.legalText}>Términos de Servicio</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.legalItem}>
            <Text style={styles.legalText}>Política de Privacidad</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.legalItem}>
            <Text style={styles.legalText}>Contactar Soporte</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.light,
  },
  settingsGroup: {
    marginBottom: 32,
  },
  groupTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.dark,
    paddingHorizontal: 20,
    marginBottom: 16,
  },
  groupItems: {
    paddingHorizontal: 20,
  },
  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: Colors.white,
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  dangerItem: {
    borderWidth: 1,
    borderColor: `${Colors.expense}20`,
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  settingIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  settingContent: {
    flex: 1,
  },
  settingTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.dark,
    marginBottom: 4,
  },
  settingSubtitle: {
    fontSize: 14,
    color: Colors.gray,
  },
  appInfo: {
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 32,
    backgroundColor: Colors.white,
    marginHorizontal: 20,
    borderRadius: 16,
    marginBottom: 24,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  appName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: Colors.primary,
    marginBottom: 8,
  },
  appVersion: {
    fontSize: 16,
    color: Colors.gray,
    marginBottom: 12,
  },
  appDescription: {
    fontSize: 14,
    color: Colors.gray,
    textAlign: 'center',
    lineHeight: 20,
  },
  legalSection: {
    paddingHorizontal: 20,
    marginBottom: 32,
  },
  legalItem: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: Colors.lightGray,
  },
  legalText: {
    fontSize: 16,
    color: Colors.primary,
    textAlign: 'center',
  },
});