import React from 'react';
import { 
  StyleSheet, 
  Text, 
  View, 
  ScrollView, 
  TouchableOpacity,
  Alert 
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Stack } from 'expo-router';
import * as DocumentPicker from 'expo-document-picker';
import * as ImagePicker from 'expo-image-picker';
import { 
  Upload, 
  FileText, 
  Image as ImageIcon, 
  Camera,
  Bot,
  CheckCircle,
  AlertCircle
} from 'lucide-react-native';
import { Colors } from '@/constants/colors';

export default function ImportScreen() {
  const [isProcessing, setIsProcessing] = React.useState(false);
  const [selectedFile, setSelectedFile] = React.useState<any>(null);

  const handleFileSelected = (file: any) => {
    console.log('Selected file:', file);
    setSelectedFile(file);
  };

  const handleGeminiProcessing = async () => {
    if (!selectedFile) return;

    setIsProcessing(true);
    try {
      // Simulate AI processing
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      Alert.alert(
        'Procesamiento Completado',
        'El archivo ha sido procesado exitosamente. Se encontraron 12 transacciones.',
        [
          { text: 'Ver Resultados', onPress: () => console.log('Show results') },
          { text: 'OK', onPress: () => setSelectedFile(null) }
        ]
      );
    } catch (error) {
      console.error('Error processing file:', error);
      Alert.alert('Error', 'No se pudo procesar el archivo');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDocumentPick = async (types: string[]) => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: types,
        copyToCacheDirectory: true,
      });

      if (!result.canceled && result.assets[0]) {
        handleFileSelected(result.assets[0]);
      }
    } catch (error) {
      console.error('Error picking document:', error);
      Alert.alert('Error', 'No se pudo seleccionar el archivo');
    }
  };

  const handleCameraCapture = async () => {
    try {
      const { status } = await ImagePicker.requestCameraPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permisos', 'Se necesitan permisos de cámara para esta función');
        return;
      }

      const result = await ImagePicker.launchCameraAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 1,
      });

      if (!result.canceled && result.assets[0]) {
        handleFileSelected(result.assets[0]);
      }
    } catch (error) {
      console.error('Error capturing image:', error);
      Alert.alert('Error', 'No se pudo capturar la imagen');
    }
  };

  const handleImagePick = async () => {
    try {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permisos', 'Se necesitan permisos de galería para esta función');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 1,
      });

      if (!result.canceled && result.assets[0]) {
        handleFileSelected(result.assets[0]);
      }
    } catch (error) {
      console.error('Error picking image:', error);
      Alert.alert('Error', 'No se pudo seleccionar la imagen');
    }
  };

  const importOptions = [
    {
      title: 'Archivo CSV',
      description: 'Importa transacciones desde archivos CSV',
      icon: FileText,
      color: Colors.success,
      action: () => handleDocumentPick(['text/csv', 'application/csv'])
    },
    {
      title: 'Archivo PDF',
      description: 'Extrae datos de estados de cuenta en PDF',
      icon: FileText,
      color: Colors.primary,
      action: () => handleDocumentPick(['application/pdf'])
    },
    {
      title: 'Tomar Foto',
      description: 'Captura recibos o documentos con la cámara',
      icon: Camera,
      color: Colors.warning,
      action: handleCameraCapture
    },
    {
      title: 'Seleccionar Imagen',
      description: 'Elige una imagen de tu galería',
      icon: ImageIcon,
      color: Colors.info,
      action: handleImagePick
    },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <Stack.Screen 
        options={{ 
          title: 'Importar Datos',
          headerStyle: { backgroundColor: Colors.light },
          headerTintColor: Colors.dark,
        }} 
      />
      
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.aiIcon}>
            <Bot color={Colors.primary} size={32} />
          </View>
          <Text style={styles.title}>Importación Inteligente</Text>
          <Text style={styles.subtitle}>
            Usa IA para extraer automáticamente datos financieros de tus documentos
          </Text>
        </View>

        {/* Import Options */}
        {!selectedFile && (
          <View style={styles.optionsContainer}>
            {importOptions.map((option, index) => {
              const IconComponent = option.icon;
              return (
                <TouchableOpacity 
                  key={index} 
                  style={[styles.optionCard, isProcessing && styles.disabledCard]}
                  onPress={option.action}
                  disabled={isProcessing}
                >
                  <View style={[styles.optionIcon, { backgroundColor: `${option.color}20` }]}>
                    <IconComponent color={option.color} size={24} />
                  </View>
                  <View style={styles.optionContent}>
                    <Text style={styles.optionTitle}>{option.title}</Text>
                    <Text style={styles.optionDescription}>{option.description}</Text>
                  </View>
                  <Upload color={Colors.gray} size={20} />
                </TouchableOpacity>
              );
            })}
          </View>
        )}

        {/* Selected File & Process Button */}
        {selectedFile && !isProcessing && (
          <View style={styles.selectedFileContainer}>
            <View style={styles.fileInfo}>
              <FileText color={Colors.dark} size={20} />
              <Text style={styles.fileName} numberOfLines={1}>{selectedFile.name}</Text>
            </View>
            <TouchableOpacity style={styles.processButton} onPress={handleGeminiProcessing}>
              <Bot color={Colors.white} size={20} style={{ marginRight: 8 }}/>
              <Text style={styles.processButtonText}>Procesar con Gemini</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* Processing Status */}
        {isProcessing && (
          <View style={styles.processingCard}>
            <Bot color={Colors.primary} size={24} />
            <Text style={styles.processingText}>Procesando con IA...</Text>
            <Text style={styles.processingSubtext}>
              Extrayendo datos financieros del documento
            </Text>
          </View>
        )}

        {/* Supported Formats */}
        <View style={styles.supportedSection}>
          <Text style={styles.supportedTitle}>Formatos Soportados</Text>
          <View style={styles.formatsList}>
            <View style={styles.formatItem}>
              <CheckCircle color={Colors.success} size={16} />
              <Text style={styles.formatText}>CSV - Archivos de transacciones</Text>
            </View>
            <View style={styles.formatItem}>
              <CheckCircle color={Colors.success} size={16} />
              <Text style={styles.formatText}>PDF - Estados de cuenta bancarios</Text>
            </View>
            <View style={styles.formatItem}>
              <CheckCircle color={Colors.success} size={16} />
              <Text style={styles.formatText}>JPG/PNG - Recibos y facturas</Text>
            </View>
          </View>
        </View>

        {/* Tips */}
        <View style={styles.tipsSection}>
          <Text style={styles.tipsTitle}>Consejos para mejores resultados</Text>
          <View style={styles.tipsList}>
            <View style={styles.tipItem}>
              <AlertCircle color={Colors.warning} size={16} />
              <Text style={styles.tipText}>
                Asegúrate de que las imágenes sean claras y legibles
              </Text>
            </View>
            <View style={styles.tipItem}>
              <AlertCircle color={Colors.warning} size={16} />
              <Text style={styles.tipText}>
                Los archivos CSV deben tener columnas de fecha, descripción y monto
              </Text>
            </View>
            <View style={styles.tipItem}>
              <AlertCircle color={Colors.warning} size={16} />
              <Text style={styles.tipText}>
                Revisa siempre los datos importados antes de guardar
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.light,
  },
  header: {
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 32,
  },
  aiIcon: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: `${Colors.primary}15`,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: Colors.dark,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: Colors.gray,
    textAlign: 'center',
    lineHeight: 22,
  },
  optionsContainer: {
    paddingHorizontal: 20,
    marginBottom: 32,
  },
  optionCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.white,
    padding: 20,
    borderRadius: 16,
    marginBottom: 16,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  disabledCard: {
    opacity: 0.5,
  },
  optionIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  optionContent: {
    flex: 1,
  },
  optionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: Colors.dark,
    marginBottom: 4,
  },
  optionDescription: {
    fontSize: 14,
    color: Colors.gray,
  },
  selectedFileContainer: {
    marginHorizontal: 20,
    marginBottom: 32,
    backgroundColor: Colors.white,
    borderRadius: 16,
    padding: 20,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  fileInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  fileName: {
    fontSize: 16,
    color: Colors.dark,
    marginLeft: 12,
    flex: 1,
  },
  processButton: {
    backgroundColor: Colors.primary,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    borderRadius: 12,
  },
  processButtonText: {
    color: Colors.white,
    fontSize: 16,
    fontWeight: 'bold',
  },
  processingCard: {
    alignItems: 'center',
    backgroundColor: Colors.white,
    marginHorizontal: 20,
    padding: 24,
    borderRadius: 16,
    marginBottom: 32,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  processingText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.primary,
    marginTop: 12,
    marginBottom: 8,
  },
  processingSubtext: {
    fontSize: 14,
    color: Colors.gray,
    textAlign: 'center',
  },
  supportedSection: {
    paddingHorizontal: 20,
    marginBottom: 32,
  },
  supportedTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.dark,
    marginBottom: 16,
  },
  formatsList: {
    backgroundColor: Colors.white,
    borderRadius: 16,
    padding: 16,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  formatItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    gap: 12,
  },
  formatText: {
    fontSize: 14,
    color: Colors.dark,
  },
  tipsSection: {
    paddingHorizontal: 20,
    marginBottom: 32,
  },
  tipsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.dark,
    marginBottom: 16,
  },
  tipsList: {
    backgroundColor: Colors.white,
    borderRadius: 16,
    padding: 16,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  tipItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    paddingVertical: 8,
    gap: 12,
  },
  tipText: {
    fontSize: 14,
    color: Colors.dark,
    flex: 1,
    lineHeight: 20,
  },
});
