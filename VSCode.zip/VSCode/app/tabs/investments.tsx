import React from 'react';
import { 
  StyleSheet, 
  Text, 
  View, 
  ScrollView, 
  TouchableOpacity
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LineChart, TrendingUp, TrendingDown, Plus, BarChart3 } from 'lucide-react-native';
import { Colors } from '@/constants/colors';



export default function InvestmentsScreen() {
  const portfolio = [
    { 
      name: 'Acciones Tech', 
      value: 3500, 
      change: 12.5, 
      percentage: 39,
      color: '#3B82F6',
      icon: '📱'
    },
    { 
      name: 'ETFs', 
      value: 2800, 
      change: 8.2, 
      percentage: 31,
      color: '#10B981',
      icon: '📊'
    },
    { 
      name: 'Bonos', 
      value: 1500, 
      change: 3.1, 
      percentage: 17,
      color: '#F59E0B',
      icon: '🏛️'
    },
    { 
      name: 'Crypto', 
      value: 1120, 
      change: -5.8, 
      percentage: 13,
      color: '#8B5CF6',
      icon: '₿'
    },
  ];

  const monthlyPerformance = [
    { month: 'Ene', value: 8200 },
    { month: 'Feb', value: 8450 },
    { month: 'Mar', value: 8100 },
    { month: 'Abr', value: 8650 },
    { month: 'May', value: 8920 },
    { month: 'Jun', value: 8920 },
  ];

  const totalValue = portfolio.reduce((sum, item) => sum + item.value, 0);
  const totalChange = portfolio.reduce((sum, item) => sum + (item.value * item.change / 100), 0);
  const totalChangePercent = (totalChange / totalValue) * 100;

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Inversiones</Text>
          <TouchableOpacity style={styles.addButton}>
            <Plus color={Colors.white} size={20} />
          </TouchableOpacity>
        </View>

        {/* Portfolio Value Card */}
        <View style={styles.totalCard}>
          <View style={styles.totalHeader}>
            <LineChart color={Colors.investment} size={24} />
            <Text style={styles.totalLabel}>Valor del Portafolio</Text>
          </View>
          <Text style={styles.totalAmount}>${totalValue.toLocaleString()}</Text>
          <View style={styles.changeContainer}>
            {totalChangePercent >= 0 ? (
              <TrendingUp color={Colors.income} size={16} />
            ) : (
              <TrendingDown color={Colors.expense} size={16} />
            )}
            <Text style={[
              styles.totalChange,
              { color: totalChangePercent >= 0 ? Colors.income : Colors.expense }
            ]}>
              {totalChangePercent >= 0 ? '+' : ''}{totalChangePercent.toFixed(1)}% 
              (${Math.abs(totalChange).toFixed(2)})
            </Text>
          </View>
        </View>

        {/* Performance Chart */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Rendimiento</Text>
            <TouchableOpacity style={styles.periodButton}>
              <BarChart3 color={Colors.primary} size={16} />
              <Text style={styles.periodText}>6M</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.chart}>
            {monthlyPerformance.map((performance, index) => {
              const maxValue = Math.max(...monthlyPerformance.map(p => p.value));
              const height = (performance.value / maxValue) * 100;
              return (
                <View key={index} style={styles.chartBar}>
                  <View 
                    style={[
                      styles.bar, 
                      { 
                        height: height,
                        backgroundColor: Colors.investment 
                      }
                    ]} 
                  />
                  <Text style={styles.barLabel}>{performance.month}</Text>
                  <Text style={styles.barAmount}>${(performance.value / 1000).toFixed(1)}k</Text>
                </View>
              );
            })}
          </View>
        </View>

        {/* Portfolio Breakdown */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Distribución del Portafolio</Text>
          <View style={styles.portfolioList}>
            {portfolio.map((asset, index) => (
              <TouchableOpacity key={index} style={styles.assetItem}>
                <View style={styles.assetLeft}>
                  <View style={[styles.assetIcon, { backgroundColor: `${asset.color}20` }]}>
                    <Text style={styles.assetIconText}>{asset.icon}</Text>
                  </View>
                  <View style={styles.assetDetails}>
                    <Text style={styles.assetName}>{asset.name}</Text>
                    <View style={styles.progressBar}>
                      <View 
                        style={[
                          styles.progressFill, 
                          { 
                            width: `${asset.percentage}%`,
                            backgroundColor: asset.color 
                          }
                        ]} 
                      />
                    </View>
                  </View>
                </View>
                <View style={styles.assetRight}>
                  <Text style={styles.assetValue}>${asset.value.toLocaleString()}</Text>
                  <View style={styles.assetChange}>
                    {asset.change >= 0 ? (
                      <TrendingUp color={Colors.income} size={12} />
                    ) : (
                      <TrendingDown color={Colors.expense} size={12} />
                    )}
                    <Text style={[
                      styles.assetChangeText,
                      { color: asset.change >= 0 ? Colors.income : Colors.expense }
                    ]}>
                      {asset.change >= 0 ? '+' : ''}{asset.change}%
                    </Text>
                  </View>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Market News */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Noticias del Mercado</Text>
          <View style={styles.newsList}>
            {[
              { 
                title: 'Tech stocks rally continues', 
                summary: 'Major tech companies show strong Q2 results',
                time: '2h ago',
                trend: 'up'
              },
              { 
                title: 'Fed maintains interest rates', 
                summary: 'Central bank keeps rates steady at 5.25%',
                time: '4h ago',
                trend: 'neutral'
              },
              { 
                title: 'Crypto market volatility', 
                summary: 'Bitcoin and Ethereum see mixed signals',
                time: '6h ago',
                trend: 'down'
              },
            ].map((news, index) => (
              <TouchableOpacity key={index} style={styles.newsItem}>
                <View style={styles.newsContent}>
                  <Text style={styles.newsTitle}>{news.title}</Text>
                  <Text style={styles.newsSummary}>{news.summary}</Text>
                  <Text style={styles.newsTime}>{news.time}</Text>
                </View>
                <View style={[
                  styles.newsTrend,
                  { 
                    backgroundColor: news.trend === 'up' ? `${Colors.income}20` : 
                                   news.trend === 'down' ? `${Colors.expense}20` : 
                                   `${Colors.gray}20`
                  }
                ]}>
                  {news.trend === 'up' ? (
                    <TrendingUp color={Colors.income} size={16} />
                  ) : news.trend === 'down' ? (
                    <TrendingDown color={Colors.expense} size={16} />
                  ) : (
                    <BarChart3 color={Colors.gray} size={16} />
                  )}
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Investment Goals */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Metas de Inversión</Text>
          <View style={styles.goalCard}>
            <View style={styles.goalHeader}>
              <Text style={styles.goalTitle}>Meta de Retiro</Text>
              <Text style={styles.goalTarget}>$100,000</Text>
            </View>
            <View style={styles.goalProgress}>
              <View style={styles.goalProgressBar}>
                <View style={[styles.goalProgressFill, { width: '8.9%' }]} />
              </View>
              <Text style={styles.goalPercentage}>8.9% completado</Text>
            </View>
            <Text style={styles.goalRemaining}>
              Faltan $91,080 para alcanzar tu meta de retiro
            </Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.light,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: Colors.dark,
  },
  addButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: Colors.investment,
    justifyContent: 'center',
    alignItems: 'center',
  },
  totalCard: {
    marginHorizontal: 20,
    marginBottom: 24,
    backgroundColor: Colors.white,
    padding: 24,
    borderRadius: 16,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  totalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  totalLabel: {
    fontSize: 16,
    color: Colors.gray,
  },
  totalAmount: {
    fontSize: 32,
    fontWeight: 'bold',
    color: Colors.investment,
    marginBottom: 8,
  },
  changeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  totalChange: {
    fontSize: 14,
    fontWeight: '600',
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: Colors.dark,
  },
  periodButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.white,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    gap: 6,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  periodText: {
    fontSize: 12,
    fontWeight: '600',
    color: Colors.primary,
  },
  chart: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    backgroundColor: Colors.white,
    padding: 20,
    borderRadius: 16,
    height: 180,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  chartBar: {
    alignItems: 'center',
    flex: 1,
  },
  bar: {
    width: 20,
    backgroundColor: Colors.investment,
    borderRadius: 10,
    marginBottom: 8,
  },
  barLabel: {
    fontSize: 12,
    color: Colors.gray,
    marginBottom: 4,
  },
  barAmount: {
    fontSize: 10,
    color: Colors.dark,
    fontWeight: '600',
  },
  portfolioList: {
    backgroundColor: Colors.white,
    borderRadius: 16,
    padding: 16,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  assetItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: Colors.lightGray,
  },
  assetLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  assetIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  assetIconText: {
    fontSize: 18,
  },
  assetDetails: {
    flex: 1,
  },
  assetName: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.dark,
    marginBottom: 8,
  },
  progressBar: {
    height: 4,
    backgroundColor: Colors.lightGray,
    borderRadius: 2,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 2,
  },
  assetRight: {
    alignItems: 'flex-end',
  },
  assetValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: Colors.dark,
    marginBottom: 4,
  },
  assetChange: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  assetChangeText: {
    fontSize: 12,
    fontWeight: '600',
  },
  newsList: {
    backgroundColor: Colors.white,
    borderRadius: 16,
    padding: 16,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  newsItem: {
    flexDirection: 'row',
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: Colors.lightGray,
    gap: 12,
  },
  newsContent: {
    flex: 1,
  },
  newsTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.dark,
    marginBottom: 4,
  },
  newsSummary: {
    fontSize: 14,
    color: Colors.gray,
    marginBottom: 8,
  },
  newsTime: {
    fontSize: 12,
    color: Colors.gray,
  },
  newsTrend: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  goalCard: {
    backgroundColor: Colors.white,
    padding: 20,
    borderRadius: 16,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  goalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  goalTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.dark,
  },
  goalTarget: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.investment,
  },
  goalProgress: {
    marginBottom: 12,
  },
  goalProgressBar: {
    height: 8,
    backgroundColor: Colors.lightGray,
    borderRadius: 4,
    overflow: 'hidden',
    marginBottom: 8,
  },
  goalProgressFill: {
    height: '100%',
    backgroundColor: Colors.investment,
    borderRadius: 4,
  },
  goalPercentage: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.investment,
    textAlign: 'right',
  },
  goalRemaining: {
    fontSize: 14,
    color: Colors.gray,
  },
});