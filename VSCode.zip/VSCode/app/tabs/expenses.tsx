import React from 'react';
import { 
  StyleSheet, 
  Text, 
  View, 
  ScrollView, 
  TouchableOpacity
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { TrendingDown, Calendar, BarChart3 } from 'lucide-react-native';
import { Colors } from '@/constants/colors';



export default function ExpensesScreen() {
  const categories = [
    { name: 'Alimentación', amount: 450.20, percentage: 35, color: '#FF6B6B', icon: '🍽️' },
    { name: 'Transporte', amount: 280.50, percentage: 22, color: '#4ECDC4', icon: '🚗' },
    { name: 'Entretenimiento', amount: 180.75, percentage: 14, color: '#45B7D1', icon: '🎬' },
    { name: 'Compras', amount: 220.30, percentage: 17, color: '#96CEB4', icon: '🛍️' },
    { name: 'Servicios', amount: 150.00, percentage: 12, color: '#FFEAA7', icon: '💡' },
  ];

  const monthlyExpenses = [
    { month: 'Ene', amount: 1200 },
    { month: 'Feb', amount: 1350 },
    { month: 'Mar', amount: 1180 },
    { month: 'Abr', amount: 1420 },
    { month: 'May', amount: 1281 },
    { month: 'Jun', amount: 1380 },
  ];

  const maxExpense = Math.max(...monthlyExpenses.map(e => e.amount));

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Gastos</Text>
          <TouchableOpacity style={styles.periodButton}>
            <Calendar color={Colors.primary} size={20} />
            <Text style={styles.periodText}>Este mes</Text>
          </TouchableOpacity>
        </View>

        {/* Total Expenses Card */}
        <View style={styles.totalCard}>
          <View style={styles.totalHeader}>
            <TrendingDown color={Colors.expense} size={24} />
            <Text style={styles.totalLabel}>Total Gastado</Text>
          </View>
          <Text style={styles.totalAmount}>$1,281.75</Text>
          <Text style={styles.totalChange}>+8.2% vs mes anterior</Text>
        </View>

        {/* Monthly Chart */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Tendencia Mensual</Text>
            <BarChart3 color={Colors.gray} size={20} />
          </View>
          <View style={styles.chart}>
            {monthlyExpenses.map((expense, index) => (
              <View key={index} style={styles.chartBar}>
                <View 
                  style={[
                    styles.bar, 
                    { 
                      height: (expense.amount / maxExpense) * 100,
                      backgroundColor: Colors.expense 
                    }
                  ]} 
                />
                <Text style={styles.barLabel}>{expense.month}</Text>
                <Text style={styles.barAmount}>${expense.amount}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Categories */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Por Categoría</Text>
          <View style={styles.categoriesList}>
            {categories.map((category, index) => (
              <TouchableOpacity key={index} style={styles.categoryItem}>
                <View style={styles.categoryLeft}>
                  <View style={[styles.categoryIcon, { backgroundColor: `${category.color}20` }]}>
                    <Text style={styles.categoryIconText}>{category.icon}</Text>
                  </View>
                  <View style={styles.categoryDetails}>
                    <Text style={styles.categoryName}>{category.name}</Text>
                    <View style={styles.progressBar}>
                      <View 
                        style={[
                          styles.progressFill, 
                          { 
                            width: `${category.percentage}%`,
                            backgroundColor: category.color 
                          }
                        ]} 
                      />
                    </View>
                  </View>
                </View>
                <View style={styles.categoryRight}>
                  <Text style={styles.categoryAmount}>${category.amount.toFixed(2)}</Text>
                  <Text style={styles.categoryPercentage}>{category.percentage}%</Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Recent Expenses */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Gastos Recientes</Text>
          <View style={styles.recentList}>
            {[
              { title: 'Supermercado', amount: 45.20, date: 'Hoy', icon: '🛒' },
              { title: 'Gasolina', amount: 35.50, date: 'Ayer', icon: '⛽' },
              { title: 'Restaurante', amount: 28.75, date: '2 días', icon: '🍽️' },
            ].map((expense, index) => (
              <View key={index} style={styles.recentItem}>
                <View style={styles.recentLeft}>
                  <Text style={styles.recentIcon}>{expense.icon}</Text>
                  <View>
                    <Text style={styles.recentTitle}>{expense.title}</Text>
                    <Text style={styles.recentDate}>{expense.date}</Text>
                  </View>
                </View>
                <Text style={styles.recentAmount}>-${expense.amount}</Text>
              </View>
            ))}
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.light,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: Colors.dark,
  },
  periodButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.white,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    gap: 8,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  periodText: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.primary,
  },
  totalCard: {
    marginHorizontal: 20,
    marginBottom: 24,
    backgroundColor: Colors.white,
    padding: 24,
    borderRadius: 16,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  totalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  totalLabel: {
    fontSize: 16,
    color: Colors.gray,
  },
  totalAmount: {
    fontSize: 32,
    fontWeight: 'bold',
    color: Colors.expense,
    marginBottom: 8,
  },
  totalChange: {
    fontSize: 14,
    color: Colors.gray,
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: Colors.dark,
  },
  chart: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    backgroundColor: Colors.white,
    padding: 20,
    borderRadius: 16,
    height: 180,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  chartBar: {
    alignItems: 'center',
    flex: 1,
  },
  bar: {
    width: 20,
    backgroundColor: Colors.expense,
    borderRadius: 10,
    marginBottom: 8,
  },
  barLabel: {
    fontSize: 12,
    color: Colors.gray,
    marginBottom: 4,
  },
  barAmount: {
    fontSize: 10,
    color: Colors.dark,
    fontWeight: '600',
  },
  categoriesList: {
    backgroundColor: Colors.white,
    borderRadius: 16,
    padding: 16,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  categoryItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: Colors.lightGray,
  },
  categoryLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  categoryIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  categoryIconText: {
    fontSize: 18,
  },
  categoryDetails: {
    flex: 1,
  },
  categoryName: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.dark,
    marginBottom: 8,
  },
  progressBar: {
    height: 4,
    backgroundColor: Colors.lightGray,
    borderRadius: 2,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 2,
  },
  categoryRight: {
    alignItems: 'flex-end',
  },
  categoryAmount: {
    fontSize: 16,
    fontWeight: 'bold',
    color: Colors.dark,
    marginBottom: 4,
  },
  categoryPercentage: {
    fontSize: 12,
    color: Colors.gray,
  },
  recentList: {
    backgroundColor: Colors.white,
    borderRadius: 16,
    padding: 16,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  recentItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: Colors.lightGray,
  },
  recentLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  recentIcon: {
    fontSize: 20,
  },
  recentTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.dark,
  },
  recentDate: {
    fontSize: 14,
    color: Colors.gray,
    marginTop: 2,
  },
  recentAmount: {
    fontSize: 16,
    fontWeight: 'bold',
    color: Colors.expense,
  },
});