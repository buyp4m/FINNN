import React from 'react';
import { 
  StyleSheet, 
  Text, 
  View, 
  ScrollView, 
  TouchableOpacity
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { TrendingUp, Calendar, Plus } from 'lucide-react-native';
import { Colors } from '@/constants/colors';



export default function IncomeScreen() {
  const incomeSources = [
    { name: 'Salario Principal', amount: 2500.00, percentage: 75, color: '#10B981', icon: '💼' },
    { name: 'Freelance', amount: 450.00, percentage: 14, color: '#3B82F6', icon: '💻' },
    { name: 'Inversiones', amount: 180.50, percentage: 5, color: '#8B5CF6', icon: '📈' },
    { name: 'Otros', amount: 200.00, percentage: 6, color: '#F59E0B', icon: '💰' },
  ];

  const monthlyIncome = [
    { month: 'Ene', amount: 3100 },
    { month: 'Feb', amount: 3250 },
    { month: 'Mar', amount: 2980 },
    { month: 'Abr', amount: 3420 },
    { month: 'May', amount: 3330 },
    { month: 'Jun', amount: 3330 },
  ];

  const maxIncome = Math.max(...monthlyIncome.map(i => i.amount));

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Ingresos</Text>
          <TouchableOpacity style={styles.addButton}>
            <Plus color={Colors.white} size={20} />
          </TouchableOpacity>
        </View>

        {/* Total Income Card */}
        <View style={styles.totalCard}>
          <View style={styles.totalHeader}>
            <TrendingUp color={Colors.income} size={24} />
            <Text style={styles.totalLabel}>Total Ingresos</Text>
          </View>
          <Text style={styles.totalAmount}>$3,330.50</Text>
          <Text style={styles.totalChange}>+5.8% vs mes anterior</Text>
        </View>

        {/* Monthly Chart */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Tendencia Mensual</Text>
            <TouchableOpacity style={styles.periodButton}>
              <Calendar color={Colors.primary} size={16} />
              <Text style={styles.periodText}>6 meses</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.chart}>
            {monthlyIncome.map((income, index) => (
              <View key={index} style={styles.chartBar}>
                <View 
                  style={[
                    styles.bar, 
                    { 
                      height: (income.amount / maxIncome) * 100,
                      backgroundColor: Colors.income 
                    }
                  ]} 
                />
                <Text style={styles.barLabel}>{income.month}</Text>
                <Text style={styles.barAmount}>${income.amount}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Income Sources */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Fuentes de Ingreso</Text>
          <View style={styles.sourcesList}>
            {incomeSources.map((source, index) => (
              <TouchableOpacity key={index} style={styles.sourceItem}>
                <View style={styles.sourceLeft}>
                  <View style={[styles.sourceIcon, { backgroundColor: `${source.color}20` }]}>
                    <Text style={styles.sourceIconText}>{source.icon}</Text>
                  </View>
                  <View style={styles.sourceDetails}>
                    <Text style={styles.sourceName}>{source.name}</Text>
                    <View style={styles.progressBar}>
                      <View 
                        style={[
                          styles.progressFill, 
                          { 
                            width: `${source.percentage}%`,
                            backgroundColor: source.color 
                          }
                        ]} 
                      />
                    </View>
                  </View>
                </View>
                <View style={styles.sourceRight}>
                  <Text style={styles.sourceAmount}>${source.amount.toFixed(2)}</Text>
                  <Text style={styles.sourcePercentage}>{source.percentage}%</Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Recent Income */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Ingresos Recientes</Text>
          <View style={styles.recentList}>
            {[
              { title: 'Salario Mensual', amount: 2500.00, date: 'Hace 2 días', icon: '💼' },
              { title: 'Proyecto Freelance', amount: 450.00, date: 'Hace 4 días', icon: '💻' },
              { title: 'Dividendos', amount: 180.50, date: 'Hace 1 semana', icon: '📈' },
            ].map((income, index) => (
              <View key={index} style={styles.recentItem}>
                <View style={styles.recentLeft}>
                  <Text style={styles.recentIcon}>{income.icon}</Text>
                  <View>
                    <Text style={styles.recentTitle}>{income.title}</Text>
                    <Text style={styles.recentDate}>{income.date}</Text>
                  </View>
                </View>
                <Text style={styles.recentAmount}>+${income.amount}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Goals Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Meta de Ingresos</Text>
          <View style={styles.goalCard}>
            <View style={styles.goalHeader}>
              <Text style={styles.goalTitle}>Meta Mensual</Text>
              <Text style={styles.goalTarget}>$4,000</Text>
            </View>
            <View style={styles.goalProgress}>
              <View style={styles.goalProgressBar}>
                <View style={[styles.goalProgressFill, { width: '83%' }]} />
              </View>
              <Text style={styles.goalPercentage}>83% completado</Text>
            </View>
            <Text style={styles.goalRemaining}>Faltan $669.50 para alcanzar tu meta</Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.light,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: Colors.dark,
  },
  addButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: Colors.income,
    justifyContent: 'center',
    alignItems: 'center',
  },
  totalCard: {
    marginHorizontal: 20,
    marginBottom: 24,
    backgroundColor: Colors.white,
    padding: 24,
    borderRadius: 16,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  totalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  totalLabel: {
    fontSize: 16,
    color: Colors.gray,
  },
  totalAmount: {
    fontSize: 32,
    fontWeight: 'bold',
    color: Colors.income,
    marginBottom: 8,
  },
  totalChange: {
    fontSize: 14,
    color: Colors.gray,
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: Colors.dark,
  },
  periodButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.white,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    gap: 6,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  periodText: {
    fontSize: 12,
    fontWeight: '600',
    color: Colors.primary,
  },
  chart: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    backgroundColor: Colors.white,
    padding: 20,
    borderRadius: 16,
    height: 180,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  chartBar: {
    alignItems: 'center',
    flex: 1,
  },
  bar: {
    width: 20,
    backgroundColor: Colors.income,
    borderRadius: 10,
    marginBottom: 8,
  },
  barLabel: {
    fontSize: 12,
    color: Colors.gray,
    marginBottom: 4,
  },
  barAmount: {
    fontSize: 10,
    color: Colors.dark,
    fontWeight: '600',
  },
  sourcesList: {
    backgroundColor: Colors.white,
    borderRadius: 16,
    padding: 16,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  sourceItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: Colors.lightGray,
  },
  sourceLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  sourceIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sourceIconText: {
    fontSize: 18,
  },
  sourceDetails: {
    flex: 1,
  },
  sourceName: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.dark,
    marginBottom: 8,
  },
  progressBar: {
    height: 4,
    backgroundColor: Colors.lightGray,
    borderRadius: 2,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 2,
  },
  sourceRight: {
    alignItems: 'flex-end',
  },
  sourceAmount: {
    fontSize: 16,
    fontWeight: 'bold',
    color: Colors.dark,
    marginBottom: 4,
  },
  sourcePercentage: {
    fontSize: 12,
    color: Colors.gray,
  },
  recentList: {
    backgroundColor: Colors.white,
    borderRadius: 16,
    padding: 16,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  recentItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: Colors.lightGray,
  },
  recentLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  recentIcon: {
    fontSize: 20,
  },
  recentTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.dark,
  },
  recentDate: {
    fontSize: 14,
    color: Colors.gray,
    marginTop: 2,
  },
  recentAmount: {
    fontSize: 16,
    fontWeight: 'bold',
    color: Colors.income,
  },
  goalCard: {
    backgroundColor: Colors.white,
    padding: 20,
    borderRadius: 16,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  goalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  goalTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.dark,
  },
  goalTarget: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.income,
  },
  goalProgress: {
    marginBottom: 12,
  },
  goalProgressBar: {
    height: 8,
    backgroundColor: Colors.lightGray,
    borderRadius: 4,
    overflow: 'hidden',
    marginBottom: 8,
  },
  goalProgressFill: {
    height: '100%',
    backgroundColor: Colors.income,
    borderRadius: 4,
  },
  goalPercentage: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.income,
    textAlign: 'right',
  },
  goalRemaining: {
    fontSize: 14,
    color: Colors.gray,
  },
});