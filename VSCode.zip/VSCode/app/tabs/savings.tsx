import React from 'react';
import { 
  StyleSheet, 
  Text, 
  View, 
  ScrollView, 
  TouchableOpacity
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { PiggyBank, Target, Plus, TrendingUp } from 'lucide-react-native';
import { Colors } from '@/constants/colors';



export default function SavingsScreen() {
  const savingsGoals = [
    { 
      name: 'Fondo de Emergencia', 
      current: 2500, 
      target: 5000, 
      color: '#EF4444',
      icon: '🚨',
      deadline: '6 meses'
    },
    { 
      name: 'Vacaciones', 
      current: 800, 
      target: 2000, 
      color: '#F59E0B',
      icon: '✈️',
      deadline: '4 meses'
    },
    { 
      name: 'Auto Nuevo', 
      current: 5200, 
      target: 15000, 
      color: '#10B981',
      icon: '🚗',
      deadline: '18 meses'
    },
    { 
      name: 'Casa', 
      current: 12000, 
      target: 50000, 
      color: '#8B5CF6',
      icon: '🏠',
      deadline: '5 años'
    },
  ];

  const monthlySavings = [
    { month: 'Ene', amount: 450 },
    { month: 'Feb', amount: 520 },
    { month: 'Mar', amount: 380 },
    { month: 'Abr', amount: 620 },
    { month: 'May', amount: 580 },
    { month: 'Jun', amount: 650 },
  ];

  const maxSavings = Math.max(...monthlySavings.map(s => s.amount));
  const totalSaved = savingsGoals.reduce((sum, goal) => sum + goal.current, 0);

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Ahorros</Text>
          <TouchableOpacity style={styles.addButton}>
            <Plus color={Colors.white} size={20} />
          </TouchableOpacity>
        </View>

        {/* Total Savings Card */}
        <View style={styles.totalCard}>
          <View style={styles.totalHeader}>
            <PiggyBank color={Colors.savings} size={24} />
            <Text style={styles.totalLabel}>Total Ahorrado</Text>
          </View>
          <Text style={styles.totalAmount}>${totalSaved.toLocaleString()}</Text>
          <Text style={styles.totalChange}>+12.3% este mes</Text>
        </View>

        {/* Monthly Savings Chart */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Ahorro Mensual</Text>
            <TrendingUp color={Colors.gray} size={20} />
          </View>
          <View style={styles.chart}>
            {monthlySavings.map((saving, index) => (
              <View key={index} style={styles.chartBar}>
                <View 
                  style={[
                    styles.bar, 
                    { 
                      height: (saving.amount / maxSavings) * 100,
                      backgroundColor: Colors.savings 
                    }
                  ]} 
                />
                <Text style={styles.barLabel}>{saving.month}</Text>
                <Text style={styles.barAmount}>${saving.amount}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Savings Goals */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Metas de Ahorro</Text>
            <TouchableOpacity style={styles.newGoalButton}>
              <Target color={Colors.primary} size={16} />
              <Text style={styles.newGoalText}>Nueva Meta</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.goalsList}>
            {savingsGoals.map((goal, index) => {
              const progress = (goal.current / goal.target) * 100;
              return (
                <TouchableOpacity key={index} style={styles.goalItem}>
                  <View style={styles.goalHeader}>
                    <View style={styles.goalLeft}>
                      <View style={[styles.goalIcon, { backgroundColor: `${goal.color}20` }]}>
                        <Text style={styles.goalIconText}>{goal.icon}</Text>
                      </View>
                      <View style={styles.goalDetails}>
                        <Text style={styles.goalName}>{goal.name}</Text>
                        <Text style={styles.goalDeadline}>{goal.deadline}</Text>
                      </View>
                    </View>
                    <View style={styles.goalRight}>
                      <Text style={styles.goalAmount}>
                        ${goal.current.toLocaleString()} / ${goal.target.toLocaleString()}
                      </Text>
                      <Text style={[styles.goalProgress, { color: goal.color }]}>
                        {progress.toFixed(0)}%
                      </Text>
                    </View>
                  </View>
                  <View style={styles.progressContainer}>
                    <View style={styles.progressBar}>
                      <View 
                        style={[
                          styles.progressFill, 
                          { 
                            width: `${Math.min(progress, 100)}%`,
                            backgroundColor: goal.color 
                          }
                        ]} 
                      />
                    </View>
                  </View>
                </TouchableOpacity>
              );
            })}
          </View>
        </View>

        {/* Savings Tips */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Consejos de Ahorro</Text>
          <View style={styles.tipsList}>
            {[
              { 
                title: 'Automatiza tus ahorros', 
                description: 'Configura transferencias automáticas cada mes',
                icon: '🤖'
              },
              { 
                title: 'Regla 50/30/20', 
                description: '50% necesidades, 30% deseos, 20% ahorros',
                icon: '📊'
              },
              { 
                title: 'Revisa tus gastos', 
                description: 'Identifica gastos innecesarios para ahorrar más',
                icon: '🔍'
              },
            ].map((tip, index) => (
              <View key={index} style={styles.tipItem}>
                <Text style={styles.tipIcon}>{tip.icon}</Text>
                <View style={styles.tipContent}>
                  <Text style={styles.tipTitle}>{tip.title}</Text>
                  <Text style={styles.tipDescription}>{tip.description}</Text>
                </View>
              </View>
            ))}
          </View>
        </View>

        {/* Savings Calculator */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Calculadora de Ahorros</Text>
          <TouchableOpacity style={styles.calculatorCard}>
            <View style={styles.calculatorContent}>
              <Text style={styles.calculatorTitle}>¿Cuánto necesitas ahorrar?</Text>
              <Text style={styles.calculatorDescription}>
                Calcula cuánto ahorrar mensualmente para alcanzar tus metas
              </Text>
            </View>
            <View style={styles.calculatorIcon}>
              <Text style={styles.calculatorIconText}>🧮</Text>
            </View>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.light,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: Colors.dark,
  },
  addButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: Colors.savings,
    justifyContent: 'center',
    alignItems: 'center',
  },
  totalCard: {
    marginHorizontal: 20,
    marginBottom: 24,
    backgroundColor: Colors.white,
    padding: 24,
    borderRadius: 16,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  totalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  totalLabel: {
    fontSize: 16,
    color: Colors.gray,
  },
  totalAmount: {
    fontSize: 32,
    fontWeight: 'bold',
    color: Colors.savings,
    marginBottom: 8,
  },
  totalChange: {
    fontSize: 14,
    color: Colors.gray,
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: Colors.dark,
  },
  newGoalButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.white,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    gap: 6,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  newGoalText: {
    fontSize: 12,
    fontWeight: '600',
    color: Colors.primary,
  },
  chart: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    backgroundColor: Colors.white,
    padding: 20,
    borderRadius: 16,
    height: 180,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  chartBar: {
    alignItems: 'center',
    flex: 1,
  },
  bar: {
    width: 20,
    backgroundColor: Colors.savings,
    borderRadius: 10,
    marginBottom: 8,
  },
  barLabel: {
    fontSize: 12,
    color: Colors.gray,
    marginBottom: 4,
  },
  barAmount: {
    fontSize: 10,
    color: Colors.dark,
    fontWeight: '600',
  },
  goalsList: {
    gap: 16,
  },
  goalItem: {
    backgroundColor: Colors.white,
    padding: 20,
    borderRadius: 16,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  goalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  goalLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  goalIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  goalIconText: {
    fontSize: 20,
  },
  goalDetails: {
    flex: 1,
  },
  goalName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: Colors.dark,
    marginBottom: 4,
  },
  goalDeadline: {
    fontSize: 14,
    color: Colors.gray,
  },
  goalRight: {
    alignItems: 'flex-end',
  },
  goalAmount: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.dark,
    marginBottom: 4,
  },
  goalProgress: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  progressContainer: {
    marginTop: 8,
  },
  progressBar: {
    height: 8,
    backgroundColor: Colors.lightGray,
    borderRadius: 4,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 4,
  },
  tipsList: {
    backgroundColor: Colors.white,
    borderRadius: 16,
    padding: 16,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  tipItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: Colors.lightGray,
    gap: 16,
  },
  tipIcon: {
    fontSize: 24,
  },
  tipContent: {
    flex: 1,
  },
  tipTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.dark,
    marginBottom: 4,
  },
  tipDescription: {
    fontSize: 14,
    color: Colors.gray,
  },
  calculatorCard: {
    backgroundColor: Colors.white,
    padding: 20,
    borderRadius: 16,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  calculatorContent: {
    flex: 1,
  },
  calculatorTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: Colors.dark,
    marginBottom: 8,
  },
  calculatorDescription: {
    fontSize: 14,
    color: Colors.gray,
  },
  calculatorIcon: {
    marginLeft: 16,
  },
  calculatorIconText: {
    fontSize: 32,
  },
});