import React from 'react';
import { 
  StyleSheet, 
  Text, 
  View, 
  ScrollView, 
  TouchableOpacity,
  Dimensions,
  TextInput 
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { 
  User, 
  Settings, 
  Plus, 
  Upload,
  Eye,
  EyeOff,
  TrendingUp,
  TrendingDown,
  PiggyBank,
  LineChart,
  Calendar,
  ChevronDown,
  X
} from 'lucide-react-native';
import { Colors } from '@/constants/colors';
import { useRouter } from 'expo-router';

const { width } = Dimensions.get('window');

interface DateRange {
  startDate: Date;
  endDate: Date;
}

interface FilteredData {
  balance: string;
  balanceChange: string;
  income: string;
  expenses: string;
  savings: string;
  investments: string;
}

export default function DashboardScreen() {
  const router = useRouter();
  const [balanceVisible, setBalanceVisible] = React.useState(true);
  const [dateRange, setDateRange] = React.useState<DateRange>({
    startDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // 30 days ago
    endDate: new Date()
  });
  const [showFilterModal, setShowFilterModal] = React.useState(false);
  const [tempStartDate, setTempStartDate] = React.useState('');
  const [tempEndDate, setTempEndDate] = React.useState('');

  const formatDate = (date: Date): string => {
    return date.toLocaleDateString('es-ES', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  const formatDateForInput = (date: Date): string => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${day}/${month}/${year}`;
  };

  const parseDateFromInput = (dateStr: string): Date | null => {
    const parts = dateStr.split('/');
    if (parts.length !== 3) return null;
    const day = parseInt(parts[0], 10);
    const month = parseInt(parts[1], 10) - 1;
    const year = parseInt(parts[2], 10);
    const date = new Date(year, month, day);
    if (isNaN(date.getTime())) return null;
    return date;
  };

  const getDaysDifference = (start: Date, end: Date): number => {
    const diffTime = Math.abs(end.getTime() - start.getTime());
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  };

  const getFilteredData = (range: DateRange): FilteredData => {
    const days = getDaysDifference(range.startDate, range.endDate);
    
    // Simulate data based on date range length
    if (days <= 7) {
      return {
        balance: '$12,840.30',
        balanceChange: '+1.2% en el período',
        income: '$1,240',
        expenses: '$890',
        savings: '$350',
        investments: '$0',
      };
    } else if (days <= 30) {
      return {
        balance: '$13,040.50',
        balanceChange: '+2.5% en el período',
        income: '$5,240',
        expenses: '$3,180',
        savings: '$2,060',
        investments: '$8,920',
      };
    } else if (days <= 90) {
      return {
        balance: '$15,680.75',
        balanceChange: '+8.3% en el período',
        income: '$15,720',
        expenses: '$9,540',
        savings: '$6,180',
        investments: '$12,450',
      };
    } else if (days <= 180) {
      return {
        balance: '$18,920.40',
        balanceChange: '+15.7% en el período',
        income: '$31,440',
        expenses: '$18,960',
        savings: '$12,480',
        investments: '$18,750',
      };
    } else if (days <= 365) {
      return {
        balance: '$24,350.80',
        balanceChange: '+28.4% en el período',
        income: '$62,880',
        expenses: '$37,920',
        savings: '$24,960',
        investments: '$32,100',
      };
    } else {
      return {
        balance: '$45,680.90',
        balanceChange: '+156.8% en el período',
        income: '$125,760',
        expenses: '$75,840',
        savings: '$49,920',
        investments: '$68,450',
      };
    }
  };

  const filteredData = getFilteredData(dateRange);
  const currentFilterLabel = `${formatDate(dateRange.startDate)} - ${formatDate(dateRange.endDate)}`;

  const handleApplyDateRange = () => {
    const startDate = parseDateFromInput(tempStartDate);
    const endDate = parseDateFromInput(tempEndDate);
    
    if (startDate && endDate && startDate <= endDate) {
      setDateRange({ startDate, endDate });
      setShowFilterModal(false);
    }
  };

  const handleOpenModal = () => {
    setTempStartDate(formatDateForInput(dateRange.startDate));
    setTempEndDate(formatDateForInput(dateRange.endDate));
    setShowFilterModal(true);
  };

  const setQuickRange = (days: number) => {
    const endDate = new Date();
    const startDate = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
    setTempStartDate(formatDateForInput(startDate));
    setTempEndDate(formatDateForInput(endDate));
  };

  const quickStats = [
    { title: 'Ingresos', amount: filteredData.income, color: Colors.income, icon: TrendingUp },
    { title: 'Gastos', amount: filteredData.expenses, color: Colors.expense, icon: TrendingDown },
    { title: 'Ahorros', amount: filteredData.savings, color: Colors.savings, icon: PiggyBank },
    { title: 'Inversiones', amount: filteredData.investments, color: Colors.investment, icon: LineChart },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>¡Hola!</Text>
            <Text style={styles.userName}>Bienvenido de vuelta</Text>
          </View>
          <View style={styles.headerActions}>
            <TouchableOpacity 
              style={styles.headerButton}
              onPress={() => router.push('/profile')}
            >
              <User color={Colors.gray} size={24} />
            </TouchableOpacity>
            <TouchableOpacity 
              style={styles.headerButton}
              onPress={() => router.push('/settings')}
            >
              <Settings color={Colors.gray} size={24} />
            </TouchableOpacity>
          </View>
        </View>

        {/* Date Range Filter */}
        <View style={styles.filterSection}>
          <TouchableOpacity 
            style={styles.filterButton}
            onPress={handleOpenModal}
          >
            <Calendar color={Colors.primary} size={20} />
            <Text style={styles.filterText}>{currentFilterLabel}</Text>
            <ChevronDown color={Colors.primary} size={20} />
          </TouchableOpacity>
        </View>

        {/* Balance Card */}
        <LinearGradient
          colors={[Colors.gradientStart, Colors.gradientEnd]}
          style={styles.balanceCard}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        >
          <View style={styles.balanceHeader}>
            <Text style={styles.balanceLabel}>Balance Total</Text>
            <TouchableOpacity onPress={() => setBalanceVisible(!balanceVisible)}>
              {balanceVisible ? (
                <Eye color={Colors.white} size={20} />
              ) : (
                <EyeOff color={Colors.white} size={20} />
              )}
            </TouchableOpacity>
          </View>
          <Text style={styles.balanceAmount}>
            {balanceVisible ? filteredData.balance : '••••••'}
          </Text>
          <Text style={styles.balanceSubtext}>
            {filteredData.balanceChange}
          </Text>
        </LinearGradient>

        {/* Quick Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Acciones Rápidas</Text>
          <View style={styles.quickActions}>
            <TouchableOpacity style={styles.actionButton}>
              <Plus color={Colors.white} size={24} />
              <Text style={styles.actionText}>Agregar</Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={[styles.actionButton, { backgroundColor: Colors.success }]}
              onPress={() => router.push('/import')}
            >
              <Upload color={Colors.white} size={24} />
              <Text style={styles.actionText}>Importar</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Quick Stats */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Resumen</Text>
          <View style={styles.statsGrid}>
            {quickStats.map((stat, index) => {
              const IconComponent = stat.icon;
              return (
                <View key={index} style={styles.statCard}>
                  <View style={[styles.statIcon, { backgroundColor: `${stat.color}20` }]}>
                    <IconComponent color={stat.color} size={20} />
                  </View>
                  <Text style={styles.statAmount}>{stat.amount}</Text>
                  <Text style={styles.statTitle}>{stat.title}</Text>
                </View>
              );
            })}
          </View>
        </View>

        {/* Recent Transactions Preview */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Transacciones Recientes</Text>
            <TouchableOpacity onPress={() => router.push('/(tabs)/transactions')}>
              <Text style={styles.seeAllText}>Ver todas</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.transactionsList}>
            {[1, 2, 3].map((_, index) => (
              <View key={index} style={styles.transactionItem}>
                <View style={styles.transactionLeft}>
                  <View style={[styles.transactionIcon, { backgroundColor: Colors.lightGray }]}>
                    <Text style={styles.transactionIconText}>🛒</Text>
                  </View>
                  <View>
                    <Text style={styles.transactionTitle}>Supermercado</Text>
                    <Text style={styles.transactionDate}>Hoy, 2:30 PM</Text>
                  </View>
                </View>
                <Text style={[styles.transactionAmount, { color: Colors.expense }]}>
                  -$45.20
                </Text>
              </View>
            ))}
          </View>
        </View>
      </ScrollView>

      {/* Date Range Modal */}
      {showFilterModal && (
        <View style={styles.modalOverlay}>
          <TouchableOpacity 
            style={styles.modalBackdrop}
            onPress={() => setShowFilterModal(false)}
          />
          <View style={styles.dateRangeModal}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Seleccionar Rango de Fechas</Text>
              <TouchableOpacity 
                style={styles.closeButton}
                onPress={() => setShowFilterModal(false)}
              >
                <X color={Colors.gray} size={20} />
              </TouchableOpacity>
            </View>
            
            {/* Quick Range Buttons */}
            <View style={styles.quickRangeSection}>
              <Text style={styles.quickRangeTitle}>Rangos rápidos:</Text>
              <View style={styles.quickRangeButtons}>
                <TouchableOpacity 
                  style={styles.quickRangeButton}
                  onPress={() => setQuickRange(7)}
                >
                  <Text style={styles.quickRangeButtonText}>7 días</Text>
                </TouchableOpacity>
                <TouchableOpacity 
                  style={styles.quickRangeButton}
                  onPress={() => setQuickRange(30)}
                >
                  <Text style={styles.quickRangeButtonText}>30 días</Text>
                </TouchableOpacity>
                <TouchableOpacity 
                  style={styles.quickRangeButton}
                  onPress={() => setQuickRange(90)}
                >
                  <Text style={styles.quickRangeButtonText}>3 meses</Text>
                </TouchableOpacity>
                <TouchableOpacity 
                  style={styles.quickRangeButton}
                  onPress={() => setQuickRange(365)}
                >
                  <Text style={styles.quickRangeButtonText}>1 año</Text>
                </TouchableOpacity>
              </View>
            </View>

            {/* Date Inputs */}
            <View style={styles.dateInputSection}>
              <View style={styles.dateInputGroup}>
                <Text style={styles.dateInputLabel}>Fecha de inicio:</Text>
                <TextInput
                  style={styles.dateInput}
                  value={tempStartDate}
                  onChangeText={setTempStartDate}
                  placeholder="DD/MM/AAAA"
                  placeholderTextColor={Colors.gray}
                  keyboardType="numeric"
                />
              </View>
              
              <View style={styles.dateInputGroup}>
                <Text style={styles.dateInputLabel}>Fecha de fin:</Text>
                <TextInput
                  style={styles.dateInput}
                  value={tempEndDate}
                  onChangeText={setTempEndDate}
                  placeholder="DD/MM/AAAA"
                  placeholderTextColor={Colors.gray}
                  keyboardType="numeric"
                />
              </View>
            </View>

            {/* Action Buttons */}
            <View style={styles.modalActions}>
              <TouchableOpacity 
                style={styles.cancelButton}
                onPress={() => setShowFilterModal(false)}
              >
                <Text style={styles.cancelButtonText}>Cancelar</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={styles.applyButton}
                onPress={handleApplyDateRange}
              >
                <Text style={styles.applyButtonText}>Aplicar</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.light,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  greeting: {
    fontSize: 16,
    color: Colors.gray,
  },
  userName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: Colors.dark,
    marginTop: 4,
  },
  headerActions: {
    flexDirection: 'row',
    gap: 12,
  },
  headerButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: Colors.white,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  balanceCard: {
    marginHorizontal: 20,
    marginVertical: 16,
    padding: 24,
    borderRadius: 20,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 5,
  },
  balanceHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  balanceLabel: {
    fontSize: 16,
    color: Colors.white,
    opacity: 0.9,
  },
  balanceAmount: {
    fontSize: 36,
    fontWeight: 'bold',
    color: Colors.white,
    marginBottom: 8,
  },
  balanceSubtext: {
    fontSize: 14,
    color: Colors.white,
    opacity: 0.8,
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: Colors.dark,
  },
  seeAllText: {
    fontSize: 14,
    color: Colors.primary,
    fontWeight: '600',
  },
  quickActions: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 16,
  },
  actionButton: {
    flex: 1,
    backgroundColor: Colors.primary,
    paddingVertical: 16,
    borderRadius: 12,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
  },
  actionText: {
    color: Colors.white,
    fontSize: 16,
    fontWeight: '600',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginTop: 16,
  },
  statCard: {
    width: (width - 52) / 2,
    backgroundColor: Colors.white,
    padding: 16,
    borderRadius: 12,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  statIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  statAmount: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.dark,
    marginBottom: 4,
  },
  statTitle: {
    fontSize: 14,
    color: Colors.gray,
  },
  transactionsList: {
    backgroundColor: Colors.white,
    borderRadius: 12,
    padding: 16,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  transactionItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: Colors.lightGray,
  },
  transactionLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  transactionIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  transactionIconText: {
    fontSize: 18,
  },
  transactionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.dark,
  },
  transactionDate: {
    fontSize: 14,
    color: Colors.gray,
    marginTop: 2,
  },
  transactionAmount: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  filterSection: {
    paddingHorizontal: 20,
    marginBottom: 8,
  },
  filterButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.white,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 12,
    gap: 8,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  filterText: {
    flex: 1,
    fontSize: 16,
    fontWeight: '600',
    color: Colors.dark,
  },
  modalOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalBackdrop: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  dateRangeModal: {
    backgroundColor: Colors.white,
    borderRadius: 16,
    marginHorizontal: 20,
    maxWidth: 380,
    width: '100%',
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.25,
    shadowRadius: 16,
    elevation: 8,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: Colors.lightGray,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.dark,
  },
  closeButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: Colors.lightGray,
    justifyContent: 'center',
    alignItems: 'center',
  },
  quickRangeSection: {
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: Colors.lightGray,
  },
  quickRangeTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.dark,
    marginBottom: 12,
  },
  quickRangeButtons: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  quickRangeButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: Colors.lightGray,
    borderRadius: 20,
  },
  quickRangeButtonText: {
    fontSize: 14,
    color: Colors.dark,
    fontWeight: '500',
  },
  dateInputSection: {
    padding: 20,
    gap: 16,
  },
  dateInputGroup: {
    gap: 8,
  },
  dateInputLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.dark,
  },
  dateInput: {
    borderWidth: 1,
    borderColor: Colors.lightGray,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    color: Colors.dark,
    backgroundColor: Colors.white,
  },
  modalActions: {
    flexDirection: 'row',
    padding: 20,
    gap: 12,
    borderTopWidth: 1,
    borderTopColor: Colors.lightGray,
  },
  cancelButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 12,
    backgroundColor: Colors.lightGray,
    alignItems: 'center',
  },
  cancelButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.dark,
  },
  applyButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 12,
    backgroundColor: Colors.primary,
    alignItems: 'center',
  },
  applyButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.white,
  },
});