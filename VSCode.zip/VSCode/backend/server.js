require('dotenv').config();
const express = require('express');
const cors = require('cors');
const multer = require('multer');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const pdf = require('pdf-parse');
const csv = require('csv-parser');
const stream = require('stream');

// 1. CONFIGURACIÓN INICIAL
// =========================
const app = express();
const port = process.env.PORT || 3001;

// Middlewares
app.use(cors());
app.use(express.json());

// Configuración de Multer para subida de archivos en memoria
const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

// Configuración de la API de Gemini
if (!process.env.AIzaSyD7ByAUMOeZ-qmkdFZ_QQSOyjw8gAb8roA) {
  console.error('Error: La variable de entorno GEMINI_API_KEY no está definida.');
  process.exit(1); // Detiene la aplicación si la clave no está
}
const genAI = new GoogleGenerativeAI(process.env.AIzaSyD7ByAUMOeZ-qmkdFZ_QQSOyjw8gAb8roA);


// 2. RUTA DE LA API PARA PROCESAR DOCUMENTOS
// ==========================================
app.post('/api/process-document', upload.single('file'), async (req, res) => {
  console.log('Petición recibida en /api/process-document');

  // Validar que se haya subido un archivo
  if (!req.file) {
    console.log('No se encontró ningún archivo en la petición.');
    return res.status(400).json({ error: 'No se subió ningún archivo.' });
  }

  console.log(`Archivo recibido: ${req.file.originalname}, Tipo: ${req.file.mimetype}`);

  try {
    let fileContent = '';

    // --- PASO 1: Extraer texto del archivo ---
    console.log('Paso 1: Extrayendo contenido del archivo...');
    if (req.file.mimetype === 'application/pdf') {
      // Lógica para extraer texto de un PDF
      const data = await pdf(req.file.buffer);
      fileContent = data.text;
      console.log('Contenido de PDF extraído.');

    } else if (req.file.mimetype === 'text/csv') {
      // Lógica para procesar un CSV
      // Usamos un stream para leer el buffer del CSV
      await new Promise((resolve, reject) => {
        const readableStream = new stream.Readable();
        readableStream._read = () => {}; // Implementación vacía necesaria
        readableStream.push(req.file.buffer);
        readableStream.push(null);

        readableStream
          .pipe(csv())
          .on('data', (row) => {
            // Convierte cada fila del CSV a una cadena de texto
            fileContent += JSON.stringify(row) + '\n';
          })
          .on('end', () => {
            console.log('Contenido de CSV extraído.');
            resolve();
          })
          .on('error', reject);
      });

    } else if (req.file.mimetype.startsWith('image/')) {
      // --- PASO 2 (PARA IMÁGENES): Procesar con el modelo multimodal de Gemini ---
      console.log('Paso 2: Procesando imagen con Gemini...');
      const model = genAI.getGenerativeModel({ model: "gemini-pro-vision" });
      const prompt = "Extrae las transacciones de esta imagen de un recibo o estado de cuenta. Devuelve solo un array de objetos JSON con las claves 'fecha', 'descripcion', y 'monto'.";
      
      const imagePart = {
        inlineData: {
          data: req.file.buffer.toString("base64"),
          mimeType: req.file.mimetype,
        },
      };

      const result = await model.generateContent([prompt, imagePart]);
      const response = await result.response;
      const text = response.text();
      
      console.log('Respuesta de Gemini (Visión) recibida.');
      // La respuesta de Gemini ya es el JSON que queremos, lo enviamos directamente
      return res.status(200).json({ 
        message: 'Archivo procesado con éxito por Gemini Vision', 
        data: text 
      });

    } else {
      console.log(`Tipo de archivo no soportado: ${req.file.mimetype}`);
      return res.status(400).json({ error: 'Tipo de archivo no soportado.' });
    }

    // --- PASO 3 (PARA TEXTO): Procesar contenido extraído con Gemini Pro ---
    console.log('Paso 3: Enviando contenido a Gemini Pro...');
    const model = genAI.getGenerativeModel({ model: "gemini-pro" });
    const prompt = `A partir de los siguientes datos de transacciones, extrae la información y devuélvela como un array de objetos JSON. Cada objeto debe tener las claves "fecha", "descripcion" y "monto". Aquí están los datos:\n\n${fileContent}`;

    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();

    console.log('Respuesta de Gemini (Pro) recibida.');
    res.status(200).json({ 
      message: 'Archivo procesado con éxito', 
      data: text 
    });

  } catch (error) {
    console.error('Error durante el procesamiento del archivo:', error);
    res.status(500).json({ error: 'Ocurrió un error en el servidor.' });
  }
});


// 3. INICIAR EL SERVIDOR
// =======================
app.listen(port, () => {
  console.log(`Servidor escuchando en http://localhost:${port}`);
});
