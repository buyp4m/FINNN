export const Colors = {
  primary: '#1E40AF',
  secondary: '#3B82F6',
  success: '#059669',
  danger: '#DC2626',
  warning: '#D97706',
  info: '#0891B2',
  light: '#F8FAFC',
  dark: '#1F2937',
  gray: '#6B7280',
  lightGray: '#E5E7EB',
  white: '#FFFFFF',
  black: '#000000',
  
  // Financial specific colors
  income: '#10B981',
  expense: '#EF4444',
  savings: '#8B5CF6',
  investment: '#F59E0B',
  
  // Background gradients
  gradientStart: '#1E40AF',
  gradientEnd: '#3B82F6',
};

export default {
  light: {
    text: Colors.dark,
    background: Colors.light,
    tint: Colors.primary,
    tabIconDefault: Colors.gray,
    tabIconSelected: Colors.primary,
  },
};